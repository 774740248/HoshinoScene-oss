#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 该脚本将在设备开机后作为延迟服务启动

# 下面，你也可以添加一些自己的代码


# 等待开机完成和用户解锁
wait_until_login() {
  # in case of /data encryption is disabled
  while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
  done

  # in case of the user unlocked the screen
  until [ -d "/data/data/android" ]; do
    sleep 1
  done
}

wait_until_login

# 自动启动scene
scene=com.omarea.vtools
if pidof $scene >/dev/null 2>&1; then
  am set-foreground-service-delegate --user 0 $scene start >/dev/null 2>&1
else
  am start-foreground-service -n $scene/.services.KeepAliveService
fi

