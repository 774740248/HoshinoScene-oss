#小鸟游星野作者QQ:774740248
if [[ "$KSU" == "true" ]]; then
  echo "- KernelSU 版本: $KSU_VER_CODE(用户)/$KSU_KERNEL_VER_CODE(内核)"
  if [ "$KSU_KERNEL_VER_CODE" -lt 11089 ]; then
    abort "请安装 KernelSU 管理器 v0.6.2+"
  fi
  RootImplement="KernelSU"
elif [[ "$APATCH" == "true" ]]; then
  abort "不支持 APatch"
else
  echo "- Magisk 版本: $MAGISK_VER($MAGISK_VER_CODE)"
  RootImplement="Magisk"
  [ "$MAGISK_VER_CODE" -lt 24000 ] && abort "请安装 Magisk 24.0+"
fi
#小鸟游星野
# 信息
ui_print "*********************************************
- 模块: $ZIPNAME
- 管理器: $RootImplement
 交流群:1127863495
 哈希值校验通过开始安装附加模块
*********************************************"

# 只安装模块组件
for ZIPFILE in $MODPATH/N/*.zip; do
    install_module
done
ui_print "安装成功"

exit 0